package com.enviro.assessment.grad001.persistence;

import com.enviro.assessment.grad001.models.Investor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InvestorPersistence extends JpaRepository<Investor, Integer> {
}
