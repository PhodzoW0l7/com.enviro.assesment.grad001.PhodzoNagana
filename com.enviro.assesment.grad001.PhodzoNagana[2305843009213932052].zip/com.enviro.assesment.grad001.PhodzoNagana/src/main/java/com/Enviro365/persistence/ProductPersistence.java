package com.enviro.assessment.grad001.persistence;

import com.enviro.assessment.grad001.models.Investor;
import com.enviro.assessment.grad001.models.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductPersistence extends JpaRepository<Product, Integer> {
    List<Product> findByInvestorId(int investorId);
}
